<?php
/**
 * Sound Generations functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Sound_Generations
 */
if(session_id()=='') session_start();
if ( ! function_exists( 'sg_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function sg_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Sound Generations, use a find and replace
	 * to change 'sg' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'sg', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
	
	/* Enable JetPack Social Media Icon/Menu 
	* @link https://jetpack.com/support/social-menu/
	*/
	add_theme_support( 'jetpack-social-menu' );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'sg' ),
		'utility' => esc_html__( 'Utility', 'lmc' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See https://developer.wordpress.org/themes/functionality/post-formats/
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
	) );
/**
 * Add custom styles for visual HTML WYSIWYG editor
 */
	add_editor_style( 'editor-style.css' );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'sg_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif; // sg_setup
add_action( 'after_setup_theme', 'sg_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function sg_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'sg_content_width', 704 );
}
add_action( 'after_setup_theme', 'sg_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function sg_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'sg' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer', 'sg' ),
		'id'            => 'sidebar-2',
		'description'   => '',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
		register_sidebar( array(
		'name'          => esc_html__( 'Header', 'sg' ),
		'id'            => 'sidebar-3',
		'description'   => '',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
	) );
		register_sidebar( array(
		'name'          => esc_html__( 'Calls To Action', 'sg' ),
		'id'            => 'sidebar-4',
		'description'   => '',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title hidden">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'sg_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function sg_scripts() {
	wp_enqueue_style( 'sg-style', get_stylesheet_uri() );

	wp_enqueue_script( 'sg-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );

	wp_enqueue_script( 'sg-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );
	
	wp_enqueue_script( 'sg-resizer', get_template_directory_uri() . '/js/resizer.js',null,'1.0.0',true);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'sg_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Post Format: Link
 */
function get_my_url() {
	if ( ! preg_match( '/<a\s[^>]*?href=[\'"](.+?)[\'"]/is', get_the_content(), $matches ) )
		return false;
 
	return esc_url_raw( $matches[1] );
}

/*
Hook into calendar plugin to replace view with our template
*/

add_filter ('mc_before_calendar',  'ivycat_set_calendar_filters',10,2);
add_filter('mc_after_calendar', 'ivycat_get_data', 10, 2);	

function ivycat_set_calendar_filters($meh,$args){
	
	if ($args['format'] == 'specialevents' || $args['format']=='socialevents' || isset($_GET['mc_id'])){
		add_filter('mc_display_format', 'ivycat_change_calendar_format', 20, 1 );
		add_filter( 'mc_from_date', 'ivycat_set_from', 10, 1 );
		add_filter( 'mc_to_date', 'ivycat_set_to', 10, 1 );

	}
	return $meh;
}
   
// have to get by the filter in the plugin
function ivycat_change_calendar_format($format){
	return 'list';
}

function ivycat_get_data($meh,$args){

	if ($args['format'] == 'specialevents' || $args['format']=='socialevents'){

		$category = $args['category']==''?'all':$args['category'];
		$from = empty($_SESSION['from'])?date("Y-m-d", strtotime("first day of this month")):$_SESSION['from'];
		$to = empty($_SESSION['to'])?date("Y-m-d", strtotime("last day of this month")):$_SESSION['to'];

		$event_array = my_calendar_events( $from, $to, $category, $args['ltype'], $args['lvalue'], 'calendar', $args['author'], $args['host'], '', $args['site'] );

		$_SESSION['event_array'] = $event_array;

		if ($args['format'] == 'specialevents')
			add_filter('my_calendar_body', 'ivycat_change_calendar_view');
		elseif ($args['format'] == 'socialevents')
			add_filter('my_calendar_body', 'ivycat_change_calendar_view_social');
	}
	elseif (isset($_GET['mc_id']) && is_numeric( $_GET['mc_id'] )){

		$mc_id = (int) $_GET['mc_id'] ;
		$_SESSION['mc_event']  = mc_get_event_core( $mc_id );
		add_filter('my_calendar_body', 'ivycat_change_calendar_view');
		
	}
	else ivycat_remove_filters();
				
	return $meh;
}

function ivycat_set_from($from){
   $_SESSION['from'] = $from;
   return $from;
}

function ivycat_set_to($to){
   $_SESSION['to'] = $to;
   return $to;
}
function ivycat_change_calendar_view($content){

	ivycat_remove_filters();
	if (!empty($_SESSION['event_array']) ){
		$parts = ivycat_split_content($content);
		$event_array = $_SESSION['event_array'];
		unset($_SESSION['event_array']);
		ob_start();
		include(get_stylesheet_directory().'/mctemplates/special_events.php');
	if (is_array($parts))
		return $parts[0].ob_get_clean().$parts[1]; 
		return ob_get_clean();
	}
	else if (!empty($_SESSION['mc_event'])){
		$event = $_SESSION['mc_event'];
		unset($_SESSION['mc_event']);
		ob_start();
		include(get_stylesheet_directory().'/mctemplates/single_event.php');
		return ob_get_clean(); 
	}

	return $content;
		
}
function ivycat_change_calendar_view_social($content){
	ivycat_remove_filters();
	if (!empty($_SESSION['event_array']) ){
		$parts = ivycat_split_content($content);
		$event_array = $_SESSION['event_array'];
		unset($_SESSION['event_array']);
		ob_start();
		include(get_stylesheet_directory().'/mctemplates/social_events.php');
		if (is_array($parts))
		return $parts[0].ob_get_clean().$parts[1]; 
		return ob_get_clean();
	}

	return $content;
	
}
function ivycat_split_content($content){
	list($start,$remaining) = explode('<ul',$content, 2);
	if (empty($remaining)) return $content;
	list($meh, $end) = explode('</ul>',$remaining, 2);
	if (empty($end)) return $content;
	return [$start,$end];
}
function ivycat_remove_filters(){
   remove_filter( 'my_calendar_body', 'ivycat_change_calendar_view' );
   remove_filter( 'my_calendar_body', 'ivycat_change_calendar_view_social' );
   remove_filter( 'mc_display_format', 'ivycat_change_calendar_format', 20, 1 );
   remove_filter( 'mc_from_date', 'ivycat_set_from', 10, 1 );
   remove_filter( 'mc_to_date', 'ivycat_set_to', 10, 1 );
}